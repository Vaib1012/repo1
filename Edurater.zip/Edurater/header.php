<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="headerStyle.css">
    </head>
    <body>
        <div class="topnav">
            <a class="home" href="#home">
              <img class="home_inverted" src="img/Edurater2.0.png" alt="home" style="width: 50px;">
              <img class="home_front" src="img/Edurater2.0_white.png" alt="home" style="width: 50px;">
            </a>
            <ul>
                <a href="#news">News</a>
                <a class="active" href="#schoolPage">School Page</a>
                <a href="#contact">Contact</a>
                <a href="#about">About Us</a>
                <a href="#search" class="search-button">
                    <input class="seach-box" type="text" name="" placeholder="Search..">
                </a>
            </ul>
          </div>
    </body>
    
</html>
