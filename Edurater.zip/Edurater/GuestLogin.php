<?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        include 'connection.php'; 
        $conn = OpenCon(); //connect to the db
       
        $username = test_input($_POST["username"]); 
        
        $checkuser = "SELECT user_id FROM user WHERE username=?;";
        $stmt =$conn->prepare($checkuser);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $res = $stmt->get_result();
        $num = mysqli_num_rows($res);
        echo $num;
        if($num == 0){

            $checkuser2 = "SELECT * FROM guest_user WHERE username=?;";
            $stmt2 =$conn->prepare($checkuser2);
            $stmt2->bind_param("s", $username);
            $stmt2->execute();
            $res2 = $stmt2->get_result();
            $num2 = mysqli_num_rows($res2);
            
            if($num2 == 0){
                $sql = "INSERT INTO guest_user (username)
                    VALUES (?)";
                $stmt3 = $conn->prepare($sql);

                $stmt3->bind_param("s",$username);

                if($stmt3->execute()){
                    echo "0";   //entry inserted into guest_user
                }
            }else{
                echo "1"; //username already exists in guest_user
            }
            
        } else {
             echo "-1";  //username already exists into user table
             
        }
              
    }
    
    function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
    }

?>
